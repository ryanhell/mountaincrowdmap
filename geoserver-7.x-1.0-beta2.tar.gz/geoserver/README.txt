Geoserver integration.

Provides a layer type for the OpenLayers module to display WFS layers using site-defined styling.